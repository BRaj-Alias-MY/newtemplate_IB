import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SitecomponentComponent } from './sitecomponent.component';

describe('SitecomponentComponent', () => {
  let component: SitecomponentComponent;
  let fixture: ComponentFixture<SitecomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SitecomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SitecomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
