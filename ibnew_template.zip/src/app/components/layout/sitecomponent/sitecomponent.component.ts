import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sitecomponent',
  templateUrl: './sitecomponent.component.html',
  styleUrls: ['./sitecomponent.component.css']
})
export class SitecomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
