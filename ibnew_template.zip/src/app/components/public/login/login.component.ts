import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../../services/api.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: usr;
  showalert: boolean;
  alertmsg: string;
  constructor(private fb: FormBuilder, private api: ApiService, private route: Router) { }
  ngOnInit() {
    this.user = {
      email : '',
      password : ''
    };
    if(this.api.getToken()) {
      this.route.navigate(['/dashboard']);
    }else {
     // $(".page").css("width" , "100%");
    }
  }



  login() {
    if (this.user.email && this.user.password) {
      this.api.login(this.user).subscribe(res => {
        if (res.token) {
          this.api.storageuserdata(res.token, res.user);
          this.user = {
            email : '',
            password : ''
          };
          location.reload();
        } else {
          this.showalert = true;
          this.alertmsg = res.error ? res.error : 'Login Fail...';
          this.user.password = '';
        }
      });
    } else {
      this.showalert = true;
      this.alertmsg = 'Please check all the fields.';
    }
    }


}
interface usr {
  email: string ,
  password: string
}

