import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../../services/api.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private fb: FormBuilder, private api: ApiService, private route: Router) { }

  ngOnInit() {
  }

  registerForm = this.fb.group({
    fname: [''],
    mname: [''],
    lname: [''],
    password: [''],
    email:[''],
    phone:[''],
    dob:['']
  });

  onSubmit()
  {
    console.warn(this.registerForm.value);
    this.api.add_register(this.registerForm.value).subscribe(res =>{
      if(res.status){
        Swal('Success..', 'Record insert/updated successfully.', 'success'); 
      }else{
        Swal('Oops...', 'Something went wrong!', 'error');
      }
    });

  }

}
