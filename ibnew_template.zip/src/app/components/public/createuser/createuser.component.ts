import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../../services/api.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.css']
})
export class CreateuserComponent implements OnInit {
   roles;
  constructor(private fb: FormBuilder, private api: ApiService, private route: Router) { }

  ngOnInit() {
    this.api.get_roles().subscribe(res=> this.roles = res.data);
    console.log(this.roles);
   }

  createuserForm = this.fb.group({
    fname: [''],
    mname: [''],
    lname: [''],
    password: [''],
    email:[''],
    phone:[''],
    dob:[''],
    role:[]
  });

onSubmit()
  {
    console.warn(this.createuserForm.value);
    this.api.add_user(this.createuserForm.value).subscribe(res =>{
      if(res.status){
        Swal('Success..', 'Record insert/updated successfully.', 'success'); 
      }else{
        Swal('Oops...', 'Something went wrong!', 'error');
      }
    });

  }

  get_roles(j){
    for(let i=0;i<this.roles.length;i++){
      if(this.roles[i].id==j)
        //return this.roles[i].role_name;
        console.log(this.roles[i].role_name);
    }
    return 'Type Not Defined.';
  }
}
