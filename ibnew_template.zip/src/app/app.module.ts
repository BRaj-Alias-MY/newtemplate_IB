import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { JwtInterceptor } from './jwt.interceptor';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgDatepickerModule } from 'ng2-datepicker';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ApiService } from './services/api.service';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { SampleComponent } from './sample/sample.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { ErrorComponent } from './components/public/error/error.component';
import { HeaderComponent } from './components/layout/header/header.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { SitecomponentComponent } from './components/layout/sitecomponent/sitecomponent.component';
import { LoginComponent } from './components/public/login/login.component';
import { RegistrationComponent } from './components/public/registration/registration.component';
import { ResetpasswordComponent } from './components/public/resetpassword/resetpassword.component';
import { ForgetpasswordComponent } from './components/public/forgetpassword/forgetpassword.component';
import { CreateuserComponent } from './components/public/createuser/createuser.component';

@NgModule({
  declarations: [
    AppComponent,
    SampleComponent,
    MainpageComponent,
    ErrorComponent,
    HeaderComponent,
    FooterComponent,
    SitecomponentComponent,
    LoginComponent,
    RegistrationComponent,
    ResetpasswordComponent,
    ForgetpasswordComponent,
    CreateuserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgSelectModule,
    FormsModule,
    NgxSpinnerModule,
    NgDatepickerModule,
    Ng2GoogleChartsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ApiService, { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
