import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SampleComponent } from './sample/sample.component';
import {CreateuserComponent } from '../app/components/public/createuser/createuser.component'
import { LoginComponent } from  '../app/components/public/login/login.component'
import { RegistrationComponent } from '../app/components/public/registration/registration.component'
import { MainpageComponent } from './mainpage/mainpage.component';
import { ForgetpasswordComponent } from  '../app/components/public/forgetpassword/forgetpassword.component'
const routes: Routes = [
  { path: '', redirectTo: '/main', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'main', component: MainpageComponent },
  { path: 'createuser', component: CreateuserComponent },
  { path: 'forgetpassword', component: ForgetpasswordComponent },
  {path : 'registration', component: RegistrationComponent}

];

@NgModule({
  declarations: [],
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
