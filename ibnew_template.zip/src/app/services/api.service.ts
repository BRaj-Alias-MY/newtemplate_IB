import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  base = "http://192.168.0.60:3000/";
  auth_token: any;
  user: any;

  constructor(private http: HttpClient) { }

  get_base() : string {
    return this.base;
  }

  storageuserdata(token,user): void {
    localStorage.setItem('token',token);
    localStorage.setItem('user', JSON.stringify(user));
    this.auth_token = token;
    this.user = user;
  }

  loadToken() {
    this.auth_token = localStorage.getItem('token');
  }

  logout(): any{
    this.auth_token = null;
    this.user = null;
    localStorage.clear();
    //return this.http.post<any>(this.base+'api/logout');
  }
  getToken(): string {
    return localStorage.getItem('token');
  }
  
  add_register(data): any {
    //user.password = this.encryptdata(user.password);
    return this.http.post<any>(this.base+'signup',data);
  }

  add_user(data): any {
    //user.password = this.encryptdata(user.password);
    return this.http.post<any>(this.base+'signup',data);
  }
  
  get_roles(){
    return this.http.get<any>(this.base+'get-users');
  }

  add_reset(data): any {
    return this.http.post<any>(this.base+'change-password',data);
  }

  login(user): any {
    return this.http.post<any>(this.base+'login',user);
  }

  forgetpwd(data): any{
    return this.http.post<any>(this.base+'api/login',data);

  }

}
